defmodule InventoryManager do
  # 1. Estado inicial del inventario y del carrito
  def new_inventory(), do: []
  def new_cart(), do: []

  # 2. Agregar un producto al inventario
  def add_product(inventory, name, price, stock) do
    id = case Enum.empty?(inventory) do
      true -> 1
      false -> Enum.max_by(inventory, &(&1[:id]))[:id] + 1
    end

    product = %{id: id, name: name, price: price, stock: stock}
    [product | inventory]
  end

  # 3. Listar productos disponibles en el inventario
  def list_products(inventory) do
    Enum.each(inventory, fn product ->
      IO.puts("ID: #{product[:id]}, Nombre: #{product[:name]}, Precio: #{product[:price]}, Stock: #{product[:stock]}")
    end)
  end

  # 4. Aumentar el stock de un producto
  def increase_stock(inventory, id, quantity) do
    Enum.map(inventory, fn
      %{id: ^id} = product -> Map.update!(product, :stock, &(&1 + quantity))
      product -> product
    end)
  end

  # 5. Vender un producto (reducir stock y agregar al carrito)
  def sell_product(inventory, cart, id, quantity) do
    {updated_inventory, product} = Enum.reduce_while(inventory, {[], nil}, fn
      %{id: ^id, stock: stock} = prod, {acc_inventory, nil} when stock >= quantity ->
        {:halt, {acc_inventory ++ [%{prod | stock: stock - quantity}], prod}}
      prod, {acc_inventory, _} -> {:cont, {acc_inventory ++ [prod], nil}}
    end)

    if product do
      updated_cart = add_to_cart(cart, product[:id], quantity)
      {updated_inventory, updated_cart}
    else
      IO.puts("Producto no disponible o stock insuficiente.")
      {inventory, cart}
    end
  end

  # 6. Agregar productos al carrito
  defp add_to_cart(cart, id, quantity) do
    case Enum.find(cart, fn {cart_id, _} -> cart_id == id end) do
      nil -> [{id, quantity} | cart]
      {^id, old_quantity} -> [{id, old_quantity + quantity} | Enum.reject(cart, fn {cart_id, _} -> cart_id == id end)]
    end
  end

  # 7. Ver el carrito de compras
  def view_cart(cart, inventory) do
    IO.puts("Carrito de Compras:")
    total_cost = Enum.reduce(cart, 0, fn {id, quantity}, acc ->
      product = Enum.find(inventory, fn %{id: product_id} -> product_id == id end)
      if product do
        IO.puts("ID: #{id}, Cantidad: #{quantity}, Precio: #{product[:price]}, Costo: #{product[:price] * quantity}")
        acc + (product[:price] * quantity)
      else
        acc
      end
    end)

    IO.puts("Total: #{total_cost}")
    total_cost
  end

  # 8. Realizar el checkout (venta final)
  def checkout(inventory, cart) do
    {updated_inventory, total_cost} = Enum.reduce(cart, {inventory, 0}, fn {id, quantity}, {inv, acc} ->
      {new_inventory, product} = Enum.reduce_while(inv, {[], nil}, fn
        %{id: ^id, stock: stock, price: _price} = prod, {acc_inventory, nil} when stock >= quantity ->  # Prefijo _ en price
          {:halt, {acc_inventory ++ [%{prod | stock: stock - quantity}], prod}}
        prod, {acc_inventory, _} -> {:cont, {acc_inventory ++ [prod], nil}}
      end)

      if product do
        {new_inventory, acc + (product[:price] * quantity)}
      else
        {inv, acc}
      end
    end)

    IO.puts("Checkout realizado con éxito. Total: #{total_cost}")
    {updated_inventory, new_cart()}
  end

  # 9. Función principal para interactuar con el usuario
  def run() do
    inventory = new_inventory()
    cart = new_cart()
    loop(inventory, cart)
  end

  # Bucle de interacción con el usuario
  defp loop(inventory, cart) do
    IO.puts("""
    Menú:
    1. Agregar producto
    2. Listar productos
    3. Aumentar stock
    4. Vender producto
    5. Ver carrito
    6. Checkout
    7. Salir
    """)

    case IO.gets("Elija una opción: ") |> String.trim() do
      "1" ->
        IO.write("Nombre del producto: ")
        name = IO.gets("") |> String.trim()
        IO.write("Precio del producto: ")
        price = IO.gets("") |> String.trim() |> String.to_float()
        IO.write("Stock inicial del producto: ")
        stock = IO.gets("") |> String.trim() |> String.to_integer()
        inventory = add_product(inventory, name, price, stock)
        loop(inventory, cart)

      "2" ->
        list_products(inventory)
        loop(inventory, cart)

      "3" ->
        IO.write("ID del producto: ")
        id = IO.gets("") |> String.trim() |> String.to_integer()
        IO.write("Cantidad a aumentar: ")
        quantity = IO.gets("") |> String.trim() |> String.to_integer()
        inventory = increase_stock(inventory, id, quantity)
        loop(inventory, cart)

      "4" ->
        IO.write("ID del producto: ")
        id = IO.gets("") |> String.trim() |> String.to_integer()
        IO.write("Cantidad a vender: ")
        quantity = IO.gets("") |> String.trim() |> String.to_integer()
        {inventory, cart} = sell_product(inventory, cart, id, quantity)
        loop(inventory, cart)

      "5" ->
        view_cart(cart, inventory)
        loop(inventory, cart)

      "6" ->
        {inventory, cart} = checkout(inventory, cart)
        loop(inventory, cart)

      "7" ->
        IO.puts("Saliendo...")
        :ok

      _ ->
        IO.puts("Opción no válida.")
        loop(inventory, cart)
    end
  end
end

# Para iniciar la aplicación:
InventoryManager.run()
