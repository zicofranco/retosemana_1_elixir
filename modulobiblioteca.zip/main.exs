defmodule Library do
  @moduledoc """
  A module for managing a library system with books and users.
  """

  defmodule Book do
    @moduledoc """
    A struct representing a book in the library.
    """
    defstruct title: "", author: "", isbn: "", available: true
  end

  defmodule User do
    @moduledoc """
    A struct representing a user of the library.
    """
    defstruct name: "", id: "", borrowed_books: []
  end

  # ... (código existente)

  @doc """
  Removes a book from the library.

  ## Parameters
  - library: The current list of books in the library.
  - isbn: The ISBN of the book to remove.

  ## Examples

      iex> library = [%Library.Book{title: "Elixir in Action", author: "Saša Jurić", isbn: "1234567890"}]
      iex> Library.remove_book(library, "1234567890")
      []
  """
  def remove_book(library, isbn) do
    Enum.filter(library, fn book -> book.isbn != isbn end)
  end

  @doc """
  Removes a user from the library system.

  ## Parameters
  - users: The current list of users.
  - user_id: The ID of the user to remove.

  ## Examples

      iex> users = [%Library.User{name: "Alice", id: "1"}]
      iex> Library.remove_user(users, "1")
      []
  """
  def remove_user(users, user_id) do
    Enum.filter(users, fn user -> user.id != user_id end)
  end

  # ... (resto del código existente)
end
