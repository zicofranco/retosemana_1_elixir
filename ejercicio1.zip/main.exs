defmodule TaskManager do
    def add_task(tasks, description) do
        new_id = length(tasks) + 1
        new_task = %{
      id: new_id,
      description: description,
      completed: false
    }
    [new_task | tasks]
  end

  def list_tasks(tasks) do
    Enum.each(tasks, fn task ->
      status = if task.completed, do: "Completed", else: "Pending"
      IO.puts("#{task.id}. #{task.description} - #{status}")
    end)
  end

  def complete_task(tasks, id) do
    Enum.map(tasks, fn
      %{
        id: ^id
      } = task -> %{task | completed: true}
      task -> task
    end)
  end

  def run do
    tasks = []

    loop(tasks)
  end

  defp loop(tasks) do
    IO.puts("Task Manager")
    IO.puts("1. Add Task")
    IO.puts("2. List Tasks")
    IO.puts("3. Complete Task")
    IO.puts("4. Exit")
    choice = IO.gets("Choose an option: ") |> String.trim() |> String.to_integer()

    case choice do
      1 ->
        description = IO.gets("Enter task description: ") |> String.trim()
        tasks = add_task(tasks, description)
        loop(tasks)

      2 ->
        list_tasks(tasks)
        loop(tasks)

      3 ->
        id = IO.gets("Enter task ID to complete: ") |> String.trim() |> String.to_integer()
        tasks = complete_task(tasks, id)
        loop(tasks)

      4 ->
        IO.puts("Hasta luego!")

      _ ->
        IO.puts("Opción Invalida. Porfavor intenta de nuevo.")
        loop(tasks)
    end
  end
end
